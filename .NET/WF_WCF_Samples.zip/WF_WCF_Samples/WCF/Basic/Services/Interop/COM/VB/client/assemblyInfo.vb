﻿' Copyright Microsoft Corporation.  All rights reserved.

Imports System
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

'<Assembly: AssemblyKeyFileAttribute("calcClientKey.snk")> 

<Assembly: AssemblyTitle("client")> 
<Assembly: AssemblyDescription("COM")> 
<Assembly: AssemblyCompany("Microsoft Corporation")> 
<Assembly: AssemblyProduct("Windows Communication Foundation and Windows Workflow Foundation SDK")> 
<Assembly: AssemblyCopyright("Copyright (c) Microsoft Corporation")> 
<Assembly: AssemblyTrademark("")> 


<Assembly: ComVisible(True)> 
<Assembly: AssemblyConfiguration("")> 
<Assembly: AssemblyCulture("")> 
