﻿Imports System
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices
Imports System.Security.Permissions

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("TracingAndLogging")> 
<Assembly: AssemblyDescription("Tracing and Logging")> 
<Assembly: AssemblyCompany("Microsoft Corporation")> 
<Assembly: AssemblyProduct("Windows Communication Foundation and Windows Workflow Foundation SDK")> 
<Assembly: AssemblyCopyright("Copyright © Microsoft Corporation")> 
<Assembly: AssemblyTrademark("")> 
<Assembly: AssemblyCulture("")> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("e9d56937-fb6e-4982-958d-e2cc39c61e37")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
<Assembly: ComVisible(False)> 