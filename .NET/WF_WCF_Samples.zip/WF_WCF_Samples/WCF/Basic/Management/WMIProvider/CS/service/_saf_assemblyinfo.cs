﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using System.Management.Instrumentation;

[assembly: Instrumented("root/ServiceModel")]
