﻿Imports System
Imports System.Reflection
Imports System.Runtime.CompilerServices
Imports System.Runtime.InteropServices
Imports System.Security.Permissions
Imports System.Management.Instrumentation

<Assembly: Instrumented("root/ServiceModel")>
